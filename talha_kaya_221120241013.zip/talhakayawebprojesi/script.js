const images = [
    "eskisehir1.jpg",
    "eskisehir2.jpg",
    "eskisehir3.jpg",
];

let currentIndex = 0;
const container = document.querySelector(".container");

function changeBackground() {
    container.style.backgroundImage = `url('${images[currentIndex]}')`;
    currentIndex = (currentIndex + 1) % images.length; 
}

changeBackground();

setInterval(changeBackground, 5000);
